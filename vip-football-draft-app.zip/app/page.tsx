'use client'

import { useState } from 'react'
import { Crown, Database } from 'lucide-react'
import { useDraft } from '@/hooks/use-draft'
import { computeChemistry } from '@/lib/chemistry'
import type { PlacedPlayer, PoolOption } from '@/lib/types'
import { Pitch } from '@/components/pitch'
import { LoungePanel } from '@/components/lounge-panel'
import { PlayerModal } from '@/components/player-modal'
import { ResumeAlert } from '@/components/resume-alert'
import { Tournament } from '@/components/tournament'
import { ExportCard } from '@/components/export-card'

export default function Page() {
  const draft = useDraft()
  const { state } = draft
  const chem = computeChemistry(state)

  const [modalPlayer, setModalPlayer] = useState<PlacedPlayer | PoolOption | null>(null)
  const [showTournament, setShowTournament] = useState(false)
  const [showExport, setShowExport] = useState(false)

  return (
    <main className="min-h-screen px-3 py-4 md:px-6 md:py-6">
      <header className="mx-auto mb-5 flex max-w-7xl flex-col items-center gap-1 text-center">
        <div className="flex items-center gap-2">
          <Crown className="h-6 w-6 text-gold" />
          <h1 className="gold-text font-heading text-2xl font-black tracking-tight md:text-4xl">
            VIP Football Draft XI
          </h1>
          <Crown className="h-6 w-6 text-gold" />
        </div>
        <p className="flex items-center gap-1.5 text-[11px] uppercase tracking-[0.3em] text-muted-foreground md:text-xs">
          <Database className="h-3 w-3" /> The Grand Archive &middot; 1980&ndash;2026
        </p>
      </header>

      <div className="mx-auto grid max-w-7xl gap-5 lg:grid-cols-[1fr_400px]">
        <section className="order-2 lg:order-1">
          <div className="glass-strong rounded-2xl p-4 md:p-6">
            <Pitch
              state={state}
              chemistry={chem}
              onRemove={draft.removePlayer}
              onInfo={(p) => setModalPlayer(p)}
            />
          </div>
        </section>

        <section className="order-1 lg:order-2">
          <div className="mb-2 flex items-center gap-2">
            <h2 className="font-heading text-sm font-bold uppercase tracking-widest text-gold">
              Grand VIP Draft Lounge
            </h2>
          </div>
          <LoungePanel
            state={state}
            rolling={draft.rolling}
            canUndo={draft.canUndo}
            canRedo={draft.canRedo}
            onFormation={draft.setFormation}
            onRollPool={draft.rollPool}
            onPick={draft.pickPlayer}
            onInfo={(p) => setModalPlayer(p)}
            onRollManager={draft.rollManager}
            onSetCaptain={draft.setCaptain}
            onSetMvp={draft.setMvp}
            onToggleSeeded={draft.toggleSeeded}
            onUndo={draft.undo}
            onRedo={draft.redo}
            onReset={draft.reset}
            onSimulate={() => setShowTournament(true)}
            onExport={() => setShowExport(true)}
          />
        </section>
      </div>

      <PlayerModal player={modalPlayer} onClose={() => setModalPlayer(null)} />
      {draft.showResume && <ResumeAlert onResume={draft.resume} onDismiss={draft.dismissResume} />}
      {showTournament && <Tournament state={state} onClose={() => setShowTournament(false)} />}
      {showExport && <ExportCard state={state} onClose={() => setShowExport(false)} />}
    </main>
  )
}
